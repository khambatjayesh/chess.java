package pieces;

import java.util.ArrayList;

import chess.Cell;

/**
 * This is the Queen Class inherited from the abstract Piece class
 *
 */
public class Queen extends Piece{
	
	//Constructors
	public Queen(String i, String p, int c)
	{
		setVariables(i, p, c);
	}
	
	//Move Function Defined
	public ArrayList<Cell> move(Cell state[][], int x, int y)
	{
		//Queen has most number of possible moves
		//Queen can move any number of steps in all 8 direction
		//The possible moves of queen is a combination of Rook and Bishop
		possiblemoves.clear();
		
		//Checking possible moves in vertical direction
		for(int posx = x-1; posx >= 0; posx--)
		{
			if(state[posx][y].getpiece() == null)
				possiblemoves.add(state[posx][y]);
			else if(state[posx][y].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][y]);
				break;
			}
		}
		
		for(int posx = x+1; posx < 8; posx++)
		{
			if(state[posx][y].getpiece() == null)
				possiblemoves.add(state[posx][y]);
			else if(state[posx][y].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][y]);
				break;
			}
		}
		
		
		//Checking possible moves in horizontal Direction
		for(int posy = y-1; posy >= 0; posy--)
		{
			if(state[x][posy].getpiece() == null)
				possiblemoves.add(state[x][posy]);
			else if(state[x][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[x][posy]);
				break;
			}
		}

		for(int posy = y+1; posy < 8; posy++)
		{
			if(state[x][posy].getpiece() == null)
				possiblemoves.add(state[x][posy]);
			else if(state[x][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[x][posy]);
				break;
			}
		}
		
		//Checking for possible moves in diagonal direction
		int posx = x+1, posy = y-1;
		while(posx<8 && posy>=0)
		{
			if(state[posx][posy].getpiece() == null)
				possiblemoves.add(state[posx][posy]);
			else if(state[posx][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][posy]);
				break;
			}
			posx++;
			posy--;
		}
		
		posx = x-1; posy = y+1;
		while(posx>=0 && posy<8)
		{
			if(state[posx][posy].getpiece() == null)
				possiblemoves.add(state[posx][posy]);
			else if(state[posx][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][posy]);
				break;
			}
			posx--;
			posy++;
		}

		posx = x-1; posy = y-1;
		while(posx>=0 && posy>=0)
		{
			if(state[posx][posy].getpiece() == null)
				possiblemoves.add(state[posx][posy]);
			else if(state[posx][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][posy]);
				break;
			}
			posx--;
			posy--;
		}

		posx = x+1; posy = y+1;
		while(posx<8 && posy<8)
		{
			if(state[posx][posy].getpiece() == null)
				possiblemoves.add(state[posx][posy]);
			else if(state[posx][posy].getpiece().color == this.color)
				break;
			else
			{
				possiblemoves.add(state[posx][posy]);
				break;
			}
			posx++;
			posy++;
		}
		return possiblemoves;
	}
}
package pieces;

import java.util.ArrayList;

import chess.Cell;


/**
 * This is the Piece Class. It is an abstract class from which all the actual pieces are inherited.
 * It defines all the function common to all the pieces
 * The move() function an abstract function that has to be overridden in all the inherited class
 * It implements Cloneable interface as a copy of the piece is required very often
 */
public abstract class Piece implements Cloneable{

	//Member Variables
	public int color;
	public String id, path;
	protected ArrayList<Cell> possiblemoves = new ArrayList<Cell>();  //Protected (access from child classes)
	public abstract ArrayList<Cell> move(Cell state[][], int x, int y);  //Abstract Function. Must be overridden
	
	public void setVariables(String id, String path, int color)
	{
		this.id = id;
		this.path = path;
		this.color = color;
	}
	
	//Function to return the a "shallow" copy of the object. The copy has exact same variable value but different reference
	public Piece getCopy() throws CloneNotSupportedException
	{
		return (Piece) this.clone();
	}
}